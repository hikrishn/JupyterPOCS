# Sani > 2022-11-17 12:29pm
https://universe.roboflow.com/object-detection/sani

Provided by a Roboflow user
License: CC BY 4.0

